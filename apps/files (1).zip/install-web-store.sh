#!/bin/bash
# =============================================================
#  depaneurIA — Installation de l'app web-store
#  Usage : bash install-web-store.sh
#  Ce script copie tous les fichiers dans votre projet
# =============================================================

set -e
VERT="\e[32m"; BLEU="\e[34m"; JAUNE="\e[33m"; RESET="\e[0m"
ok()   { echo -e "${VERT}✓ $1${RESET}"; }
info() { echo -e "${BLEU}→ $1${RESET}"; }

# Trouver le dossier du projet
PROJET="$HOME/depaneurIA"
if [ ! -d "$PROJET" ]; then
  echo -e "\e[31m✗ Dossier $PROJET introuvable. Lancez d'abord setup.sh${RESET}"
  exit 1
fi

TARGET="$PROJET/apps/web-store"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo -e "${BLEU}╔════════════════════════════════════════╗${RESET}"
echo -e "${BLEU}║   Installation de web-store            ║${RESET}"
echo -e "${BLEU}╚════════════════════════════════════════╝${RESET}"
echo ""

info "Création des dossiers..."
mkdir -p "$TARGET/src/pages"
ok "Dossiers créés"

info "Copie des fichiers web-store..."

# Liste des fichiers à copier depuis le même dossier que ce script
FILES=(
  "package.json"
  "vite.config.ts"
  "tsconfig.json"
  "index.html"
)
for f in "${FILES[@]}"; do
  if [ -f "$SCRIPT_DIR/web-store/$f" ]; then
    cp "$SCRIPT_DIR/web-store/$f" "$TARGET/$f"
    ok "  $f"
  fi
done

SRC_FILES=(
  "src/main.tsx"
  "src/index.css"
  "src/App.tsx"
  "src/types.ts"
  "src/data.ts"
  "src/pages/LoginPage.tsx"
  "src/pages/StorePage.tsx"
)
for f in "${SRC_FILES[@]}"; do
  if [ -f "$SCRIPT_DIR/web-store/$f" ]; then
    cp "$SCRIPT_DIR/web-store/$f" "$TARGET/$f"
    ok "  $f"
  fi
done

info "Installation des dépendances..."
cd "$PROJET"

# Charger nvm si disponible
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

pnpm install
ok "Dépendances installées"

echo ""
echo -e "${VERT}╔════════════════════════════════════════╗${RESET}"
echo -e "${VERT}║   ✓ web-store installé !               ║${RESET}"
echo -e "${VERT}╚════════════════════════════════════════╝${RESET}"
echo ""
echo -e "  Pour lancer le site :"
echo -e "  ${BLEU}cd ~/depaneurIA${RESET}"
echo -e "  ${BLEU}pnpm dev${RESET}"
echo ""
echo -e "  Puis ouvrez : ${JAUNE}http://localhost:5173${RESET}"
echo ""
